class Soft:
    name=""
    foldername=""
    filename=""
    row = ""
    column = ""
    cmd=""
    param=[]

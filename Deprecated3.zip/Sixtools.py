# -*- coding: utf-8 -*-

"""
Module implementing MainWindow.
"""

from PyQt4.QtCore import pyqtSlot, QDir
from PyQt4.QtGui import QMainWindow, QApplication, QTableWidgetItem, QTableWidget, QFileDialog

from DealDatebase import DataHandle as db
from Ui_SixtoolsUi import Ui_MainWindow
from entity import *

class MainWindow(QMainWindow, Ui_MainWindow):
    """
    Class documentation goes here.
    """
    def __init__(self, parent=None):
        """
        Constructor
        
        @param parent reference to the parent widget (QWidget)
        """
        super().__init__(parent)
        self.setupUi(self)
        self.tableWidget.setSelectionBehavior(QTableWidget.SelectRows)
        self.tableWidget.setSelectionMode(QTableWidget.SingleSelection)
        self.tableWidget.setAlternatingRowColors(True)
        self.tableWidget.setColumnWidth(0, 50)
        self.tableWidget.setColumnWidth(1, 450)
        self.tableWidget.setColumnWidth(2, 150)
        self.tableWidget.setColumnWidth(3, 100)
        #self.gridLayout.setColumnMinimumWidth(4, 500)
        
        
        
    @pyqtSlot(QTableWidgetItem)
    def on_tableWidget_itemDoubleClicked(self, item):
        """
        Slot documentation goes here.
        """
        # TODO: not implemented yet
        raise NotImplementedError
    
    @pyqtSlot(int, int)
    def on_tableWidget_cellClicked(self, row, column):
        """
        Slot documentation goes here.
        """
        # TODO: not implemented yet
        raise NotImplementedError
    
    @pyqtSlot(int, int)
    def on_tableWidget_cellDoubleClicked(self, row, column):
        """
        Slot documentation goes here.
        """
        # TODO: not implemented yet
        raise NotImplementedError
    
    @pyqtSlot(int, int)
    def on_tableWidget_cellChanged(self, row, column):
        """
        Slot documentation goes here.
        """
        # TODO: not implemented yet
        raise NotImplementedError
    
    @pyqtSlot()
    def on_action_triggered(self):
        """
        Slot documentation goes here.
        """
        #退出
        sys.exit(0)
    
    @pyqtSlot()
    def on_action_2_triggered(self):
        """
        Slot documentation goes here.
        """
        # TODO: not implemented yet
        #帮助
    
    @pyqtSlot()
    def on_action_3_triggered(self):
        """
        Slot documentation goes here.
        """
        # TODO: not implemented yet
        #运行
    
    @pyqtSlot()
    def on_action_4_triggered(self):
        """
        Slot documentation goes here.
        """
        # TODO: not implemented yet
        #关于
    
    @pyqtSlot()
    def on_action_5_triggered(self):
        """
        Slot documentation goes here.
        """
        # TODO: not implemented yet
        #查询
    
    @pyqtSlot()
    def on_action_6_triggered(self):
        """
        Slot documentation goes here.
        """
        # TODO: not implemented yet
        #重置
    
    @pyqtSlot()
    def on_action_7_triggered(self):
        """
        Slot documentation goes here.
        """
        # TODO: not implemented yet
        #编辑
        getInput()
        a = self.aTool.id
        if not a:
            db.insert(self.aTool)
        else:
            db.edit(self.aTool)
        
        self.aTool = Tools()
    
    @pyqtSlot()
    def on_action_8_triggered(self):
        """
        Slot documentation goes here.
        """
        # TODO: not implemented yet
        #获取位置
        currentPath = QDir.currentPath()
        filePath = QFileDialog.getOpenFileName()
        softPath = filePath.replace(currentPath, '', 1)[1:]
        self.lineEdit_4.setText(softPath)
    
    def repainData(self):
        self.tableWidget.setRowCount(len(self.tools))
        i=0
        for tool in self.tools:
            j=0
            for column in tool:
                if type(column) == type(1234):
                    column=str(column)
                item = QTableWidgetItem(column)
                self.tableWidget.setItem(i, j, item)
                j+=1
            i+=1
    
#    def getInput(self,Query):
    def getInput(self):
        #获取文本框输入内容
        id = self.lineEdit.text()
        name = self.lineEdit_2.text()
        order = self.lineEdit_3.text()
        path = self.lineEdit_4.text()
        paraString = self.lineEdit_5.text()
        content = self.lineEdit_6.text()
        
        self.aTool = Tools();
        self.aTool.id = id
        self.aTool.tool_name = name
        self.aTool.tool_order = order
        self.aTool.tool_location = path
        self.aTool.tool_content = content
        self.aTool.tool_para_string = paraString
        self.aTool.tool_para_list = paraString.split(' ')
    
    
if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    myApp = MainWindow()
    myApp.show()
    sys.exit(app.exec_())

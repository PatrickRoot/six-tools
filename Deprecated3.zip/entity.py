class Tools:
    id=''
    tool_name=''
    tool_order=''
    tool_location=''
    tool_content=''
    tool_para_string=''
    tool_para_list=[]

class ToolPara:
    id=''
    tool_id=''
    para_type_id=''
    para_name=''
    para_order=''

class ParaType:
    id=''
    para_type_name=''
    para_type_content=''
